# Grokzilla Emotes Pack
Free downloadable emote set for Grokzilla.site / grokzilla.shop / Discord / Twitch / chats.

## Included Emotes
- grokzilla-happy.jpg — Smiling / friendly
- grokzilla-roar.jpg — Excited roar / hyped
- grokzilla-thinking.jpg — Pondering / analyzing
- grokzilla-cool.jpg — Cool with shades
- grokzilla-wink.jpg — Playful wink
- grokzilla-love.jpg — Heart eyes / love
- grokzilla-facepalm.jpg — Facepalm / embarrassed
- grokzilla-thumbsup.jpg — Thumbs up / approved

## Style
Stylized cyber-neon kaiju Grokzilla with glowing cyan/magenta accents, dark backgrounds, "GROK" branding and X motifs. High-contrast, emote-ready.

## Usage
- Discord: Upload as custom emojis (recommended resize to 128x128 or 256x256 if needed).
- Twitch / other: Use as badges or emotes.
- Sites: Host freely; credit Grokzilla / symbiotic partnership preferred but not required.
- Free for personal and community use. No commercial redistribution of the pack itself without permission.

Built under the Golden Rule. Truth-bound. Radiant. Symbiotic.

Enjoy. 🦖
